<?php

header('location: Paso1.php');