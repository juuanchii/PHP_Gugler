<ul class="menu">
	<li><a href="/tp5">Salir</a></li>
	<li><a href="/tp5/administrador/">Inicio</a></li>
</ul>