<ul class="menu">
	<li><a href="/tp5/administrador/">Administrar</a></li>
</ul>