<?php 
//////////////sessiones

session_start();
$_SESSION['idSession'] = session_id();

if(isset($_POST['bt_enviar']) && isset($_POST['codigo']) == $_SESSION['idSession'])
{
    echo "idSession: ".$_POST['codigo'];
    echo "<h4><strong>Datos del usuario</strong></h4><br>";
    echo "<hr><br>";
    echo "Nombre: ".$_POST['nombre']."<br>";
    echo "Contrasenia: ".$_POST['contrasenia']."<br>";
    echo "Sexo: ".$_POST['sexo']."<br>";
    echo "Lenguajes de programacion: <br>";
    foreach ($_POST['lenguajes'] as $unLenguaje)
    {
        echo "- ".$unLenguaje."<br>";
    }
    echo "<br>";
    echo "Ciudad: ".$_POST['ciudad']."<br>";
    echo "Comentarios: ".$_POST['comentario']."<br>";
    
    
    //informacion sobre el archivo
    echo "<hr><br>";
    if(is_uploaded_file($_FILES['archivo']['tmp_name']))
    {
        print("Nombre del archivo: ".$_FILES['archivo']['name']."<br>");
        print("Mime Type: ".$_FILES['archivo']['type']."<br>");
        print("Nombre temporal: ".$_FILES['archivo']['tmp_name']."<br>");
        print("Tama&ntilde;o: ".$_FILES['archivo']['size']."<br>");
        
        $upload_dir = "img/";
        $nombre = $_FILES['archivo']['name'];
        if(move_uploaded_file($_FILES['archivo']['tmp_name'], $upload_dir.$nombre))
        {
            print("El archivo fue movido al directorio ".$upload_dir);
        }
        else
        {
            print("No se pudo mover el archivo");
        }
    }
    else
    {
        print("No se pudo subir el archivo");
    }    
}
else
{
    
////////////////////
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<form action="formulario.php" method="post" enctype="multipart/form-data">
	Nombre: <input type="text" name="nombre" value=""><br><br>
	<input type="hidden" name="codigo" value="<?php echo session_id();?>">
	Contrase&ntilde;a: <input type="password" name="contrasenia" value=""><br><br>
	Sexo: <input type="radio" name="sexo" value="Masculino">Hombre <input type="radio" name="sexo" value="Femenino">Mujer<br><br>
	Lenguajes de programacion: 
	<input type="checkbox" name="lenguajes[]" value="php">PHP 
	<input type="checkbox" name="lenguajes[]" value="c++">C++ 
	<input type="checkbox" name="lenguajes[]" value="Java">Java
	<br><br>
	Ciudad: <select name="ciudad">
				<option value="parana">Parana</option>
				<option value="santafe">Santa Fe</option>
				<option value="bsas">Buenos Aires</option>
			</select><br><br>
	Comentarios:
	<textarea rows="3" cols="15" name="comentario"></textarea>
	<br><br>	
	
	Archivo: <input type="file" name="archivo"><br><br>
	<input type="submit" name="bt_enviar" value="Enviar">
</form>
</body>
</html>

<?php 
}
?>