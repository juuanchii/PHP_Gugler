<?php
$color = 'verde';
$fruta = 'manzana';