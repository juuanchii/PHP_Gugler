<?php

$valor = "";

setcookie("prueba",$valor, time()+(60*60*24*30));