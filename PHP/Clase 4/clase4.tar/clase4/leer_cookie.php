<?php
echo $_COOKIE['prueba'];