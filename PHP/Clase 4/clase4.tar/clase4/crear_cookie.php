<?php
$valor = "Este es un valor para una cookie";

setcookie("prueba", $valor, time()+(60*60*24*30));