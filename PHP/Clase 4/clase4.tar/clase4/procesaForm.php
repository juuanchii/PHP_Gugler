<?php
session_start();

if(isset($_POST['bt_enviar']) && isset($_POST['codigo']) == $_SESSION['idSession'])
{   
    echo "idSession: ".$_POST['codigo'];
    echo "<h4><strong>Datos del usuario</strong></h4><br>";
    echo "<hr><br>";
    echo "Nombre: ".$_POST['nombre']."<br>";
    echo "Contrasenia: ".$_POST['contrasenia']."<br>";
    echo "Sexo: ".$_POST['sexo']."<br>";
    echo "Lenguajes de programacion: <br>";
    foreach ($_POST['lenguajes'] as $unLenguaje)
    {
        echo "- ".$unLenguaje."<br>";
    }
    echo "<br>";
    echo "Ciudad: ".$_POST['ciudad']."<br>";
    echo "Comentarios: ".$_POST['comentario']."<br>";
    
    
    //informacion sobre el archivo
    echo "<hr><br>";
    if(is_uploaded_file($_FILES['archivo']['tmp_name']))
    {
        print("Nombre del archivo: ".$_FILES['archivo']['name']."<br>");
        print("Mime Type: ".$_FILES['archivo']['type']."<br>");
        print("Nombre temporal: ".$_FILES['archivo']['tmp_name']."<br>");
        print("Tama&ntilde;o: ".$_FILES['archivo']['size']."<br>");
        
        $upload_dir = "img/";
        $nombre = $_FILES['archivo']['name'];
        if(move_uploaded_file($_FILES['archivo']['tmp_name'], $upload_dir.$nombre))
        {
            print("El archivo fue movido al directorio ".$upload_dir);    
        }
        else
        {
            print("No se pudo mover el archivo");
        }
    }
    else
    {
        print("No se pudo subir el archivo");
    }
    
    
}
else
{
    echo "No entro";
}
