<?php
require_once 'dir/variables.php';
echo "Una $fruta $color";