<?php

header('location: listar.php');