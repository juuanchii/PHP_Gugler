<ul class="menu">
	<li><a href="/tp6">Salir</a></li>
	<li><a href="/tp6/administrador/">Inicio</a></li>
</ul>