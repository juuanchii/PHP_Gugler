<?php

abstract class ValueObject
{

}