<footer>
<strong>Emmanuel S. Montes</strong> | <a href="mailto:emmanuel@gugler.com.ar">emmanuel@gugler.com.ar</a>
</footer>