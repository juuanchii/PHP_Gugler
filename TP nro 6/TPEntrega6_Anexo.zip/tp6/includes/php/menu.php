<ul class="menu">
	<li><a href="/tp6/administrador/">Administrar</a></li>
</ul>